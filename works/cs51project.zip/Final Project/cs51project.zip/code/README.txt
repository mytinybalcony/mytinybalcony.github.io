All the Single Characters: License Plate Localization and Character Segmentation for OCR

Chris Lim, Nhu Nguyen, Hillary Do, Annie Lin

You will need to install:
numpy
scipy
Pillow
tesseract
opencv

To use our software, run “python main.py REPLACEWITHIMAGENAME” in Terminal. 

Our algorithm only accepts pictures smaller than 1000x1000 pixels!

