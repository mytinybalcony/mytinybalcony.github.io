tesseract $1 out -psm 10
cat out.txt
